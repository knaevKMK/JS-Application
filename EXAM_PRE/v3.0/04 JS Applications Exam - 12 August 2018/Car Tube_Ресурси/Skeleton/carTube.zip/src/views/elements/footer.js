import { lp } from "../../lib.js";

export const tempFooter = () => lp.html `<div class="footer">
    <p>Created by MarikMayhem</p>
</div>`;