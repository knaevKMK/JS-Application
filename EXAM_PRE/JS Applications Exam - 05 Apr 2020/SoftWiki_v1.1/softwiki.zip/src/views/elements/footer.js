import { html } from '../../library/import.js';


export const tempFooter = () => html `<footer>My Site © Show info....</footer>`;