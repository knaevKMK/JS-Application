import { lp } from "../../lib.js";

export const tempFooter = () => lp.html ` <footer>My Site © Show info....</footer>`;